import { VehicleSearchRepository } from "@/repositories/vehicle-search.repository";
import type {
  VehicleSearchFilters,
  VehicleSearchResult,
} from "@/types/search";

export class VehicleSearchService {
  constructor(private repository: VehicleSearchRepository) {}

  async searchVehicles(
    fleetId: string | null,
    filters: VehicleSearchFilters,
  ): Promise<VehicleSearchResult[]> {
    if (!fleetId) {
      return [];
    }

    const hasAnyFilter =
      filters.query.trim().length > 0 ||
      filters.status.size > 0 ||
      filters.maint.size > 0 ||
      filters.alert.size > 0;

    if (!hasAnyFilter) {
      return [];
    }

    const normalizedFilters: VehicleSearchFilters = {
      ...filters,
      query: filters.query.trim().slice(0, 80),
    };

    try {
      return await this.repository.searchByFleet(fleetId, normalizedFilters);
    } catch {
      throw new Error("Impossible d'effectuer la recherche des véhicules.");
    }
  }
}

import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { DashboardAlert, KpiSummary } from "@/types/dashboard";

export function useDashboard(orgId: string) {
  const [alerts, setAlerts] = useState<DashboardAlert[]>([]);
  const [kpis, setKpis] = useState<KpiSummary | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [{ data: alertsData }, { data: kpiData }] = await Promise.all([
        supabase
          .from("dashboard_alerts")
          .select("*")
          .eq("org_id", orgId)
          .is("resolved_at", null)
          .order("severity_rank", { ascending: true })
          .order("created_at", { ascending: false }),

        supabase.rpc("get_kpi_summary", { p_org_id: orgId }),
      ]);

      setAlerts(alertsData ?? []);
      setKpis(kpiData ?? null);
      setLoading(false);
    }

    if (orgId) {
      load();
    } else {
      setAlerts([]);
      setKpis(null);
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    if (!orgId) {
      return;
    }

    const channel = supabase
      .channel(`dashboard-${orgId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "alerts",
          filter: `org_id=eq.${orgId}`,
        },
        (payload) => {
          setAlerts((prev) => [payload.new as DashboardAlert, ...prev]);
          setKpis((prev) =>
            prev ? { ...prev, criticalAlerts: prev.criticalAlerts + 1 } : prev
          );
        }
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "alerts",
          filter: `org_id=eq.${orgId}`,
        },
        (payload) => {
          setAlerts((prev) =>
            prev.map((a) =>
              a.id === payload.new.id ? (payload.new as DashboardAlert) : a
            )
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [orgId]);

  const resolveAlert = useCallback(
    async (alertId: string, action: DashboardAlert["action"]) => {
      setAlerts((prev) => prev.filter((a) => a.id !== alertId));
      setKpis((prev) =>
        prev
          ? { ...prev, criticalAlerts: Math.max(0, prev.criticalAlerts - 1) }
          : prev
      );

      await Promise.all([
        supabase
          .from("alerts")
          .update({ resolved_at: new Date().toISOString() })
          .eq("id", alertId),
        triggerAction(action),
      ]);
    },
    []
  );

  return { alerts, kpis, loading, resolveAlert };
}

async function triggerAction(action: DashboardAlert["action"]) {
  const fnMap: Record<DashboardAlert["action"]["kind"], string> = {
    schedule: "schedule-maintenance",
    immobilize: "immobilize-vehicle",
    book: "book-workshop",
    order: "order-parts",
    plan: "plan-service",
  };

  await supabase.functions.invoke(fnMap[action.kind], {
    body: action.payload,
  });
}

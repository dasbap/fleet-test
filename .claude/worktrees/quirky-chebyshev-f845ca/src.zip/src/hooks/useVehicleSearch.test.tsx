import { describe, expect, it, vi, beforeEach } from "vitest";
import { renderHook, waitFor, act } from "@testing-library/react";
import { useVehicleSearch } from "./useVehicleSearch";
import { createQueryClientWrapper } from "@/test/utils";

const { searchByFleetMock } = vi.hoisted(() => ({
  searchByFleetMock: vi.fn(),
}));

vi.mock("@/integrations/supabase/client", () => {
  const chain = {
    select: vi.fn().mockReturnThis(),
    eq: vi.fn().mockReturnThis(),
    or: vi.fn().mockReturnThis(),
    in: vi.fn().mockReturnThis(),
    order: vi.fn().mockReturnThis(),
    limit: searchByFleetMock,
  };

  return {
    supabase: {
      from: vi.fn(() => chain),
    },
  };
});

describe("useVehicleSearch", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("n'exécute pas la requête si fleetId est absent", async () => {
    const { result } = renderHook(() => useVehicleSearch(null), {
      wrapper: createQueryClientWrapper(),
    });

    act(() => {
      result.current.setQuery("AB-123");
    });

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 250));
    });

    expect(searchByFleetMock).not.toHaveBeenCalled();
    expect(result.current.results).toEqual([]);
  });

  it("exécute la requête avec query active et retourne les résultats", async () => {
    searchByFleetMock.mockResolvedValueOnce({
      data: [
        {
          id: "veh-1",
          fleet_id: "fleet-1",
          plate: "AB-123-CD",
          brand: "Toyota",
          model: "Hilux",
          driver_name: "Jean",
          km: 12000,
          status: "active",
          pending_maint_type: null,
          alert_severity: null,
          alert_rank: 4,
          search_text: "AB-123-CD Toyota Hilux Jean",
        },
      ],
      error: null,
    });

    const { result } = renderHook(() => useVehicleSearch("fleet-1"), {
      wrapper: createQueryClientWrapper(),
    });

    act(() => {
      result.current.setQuery("AB-123");
    });

    await waitFor(
      () => {
        expect(result.current.results.length).toBe(1);
      },
      { timeout: 2000 },
    );
  });
});

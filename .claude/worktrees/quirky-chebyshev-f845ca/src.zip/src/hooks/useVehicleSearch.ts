import { useCallback, useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { VehicleSearchRepository } from "@/repositories/vehicle-search.repository";
import { VehicleSearchService } from "@/services/vehicle-search.service";
import type { VehicleSearchFilters } from "@/types/search";

const SEARCH_DEBOUNCE_MS = 180;

const vehicleSearchRepository = new VehicleSearchRepository();
const vehicleSearchService = new VehicleSearchService(vehicleSearchRepository);

export const DEFAULT_VEHICLE_SEARCH_FILTERS: VehicleSearchFilters = {
  query: "",
  status: new Set(),
  maint: new Set(),
  alert: new Set(),
  sortBy: "plate",
};

export function useVehicleSearch(fleetId: string | null) {
  const [filters, setFilters] = useState<VehicleSearchFilters>(
    DEFAULT_VEHICLE_SEARCH_FILTERS,
  );
  const [debouncedFilters, setDebouncedFilters] = useState<VehicleSearchFilters>(
    DEFAULT_VEHICLE_SEARCH_FILTERS,
  );

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setDebouncedFilters(filters);
    }, SEARCH_DEBOUNCE_MS);
    return () => window.clearTimeout(timer);
  }, [filters]);

  const hasFilters = useMemo(
    () =>
      Boolean(
        filters.query.trim() ||
          filters.status.size ||
          filters.maint.size ||
          filters.alert.size,
      ),
    [filters],
  );

  const query = useQuery({
    queryKey: [
      "vehicle-search",
      fleetId,
      debouncedFilters.query,
      Array.from(debouncedFilters.status).sort().join(","),
      Array.from(debouncedFilters.maint).sort().join(","),
      Array.from(debouncedFilters.alert).sort().join(","),
      debouncedFilters.sortBy,
    ],
    queryFn: () => vehicleSearchService.searchVehicles(fleetId, debouncedFilters),
    enabled: Boolean(fleetId) && hasFilters,
  });

  const setQuery = useCallback((queryValue: string) => {
    setFilters((prev) => ({ ...prev, query: queryValue }));
  }, []);

  const toggleFilter = useCallback(
    <K extends "status" | "maint" | "alert">(
      group: K,
      value: VehicleSearchFilters[K] extends Set<infer T> ? T : never,
    ) => {
      setFilters((prev) => {
        const nextSet = new Set(prev[group] as Set<unknown>);
        if (nextSet.has(value)) {
          nextSet.delete(value);
        } else {
          nextSet.add(value);
        }
        return { ...prev, [group]: nextSet };
      });
    },
    [],
  );

  const setSort = useCallback((sortBy: VehicleSearchFilters["sortBy"]) => {
    setFilters((prev) => ({ ...prev, sortBy }));
  }, []);

  const reset = useCallback(() => {
    setFilters(DEFAULT_VEHICLE_SEARCH_FILTERS);
    setDebouncedFilters(DEFAULT_VEHICLE_SEARCH_FILTERS);
  }, []);

  return {
    filters,
    results: query.data ?? [],
    loading: query.isFetching,
    hasFilters,
    setQuery,
    toggleFilter,
    setSort,
    reset,
  };
}

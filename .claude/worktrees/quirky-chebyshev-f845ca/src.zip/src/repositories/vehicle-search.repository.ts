import { supabase } from "@/integrations/supabase/client";
import type {
  VehicleSearchFilters,
  VehicleSearchResult,
} from "@/types/search";

export class VehicleSearchRepository {
  async searchByFleet(
    fleetId: string,
    filters: VehicleSearchFilters,
  ): Promise<VehicleSearchResult[]> {
    let query = supabase
      .from("vehicles_search_view")
      .select("*")
      .eq("fleet_id", fleetId);

    const normalizedQuery = filters.query.trim();
    if (normalizedQuery) {
      const escaped = normalizedQuery.replace(/[%_]/g, "\\$&");
      query = query.or(
        `plate.ilike.%${escaped}%,brand.ilike.%${escaped}%,model.ilike.%${escaped}%,driver_name.ilike.%${escaped}%`,
      );
    }

    if (filters.status.size > 0) {
      query = query.in("status", Array.from(filters.status));
    }

    if (filters.maint.size > 0) {
      query = query.in("pending_maint_type", Array.from(filters.maint));
    }

    if (filters.alert.size > 0) {
      query = query.in("alert_severity", Array.from(filters.alert));
    }

    const sortMap = {
      plate: { col: "plate", asc: true },
      km: { col: "km", asc: false },
      alert: { col: "alert_rank", asc: true },
    } as const;
    const { col, asc } = sortMap[filters.sortBy];

    const { data, error } = await query.order(col, { ascending: asc }).limit(50);

    if (error) {
      console.error("Error searching vehicles:", error);
      throw new Error(error.message);
    }

    return (data || []) as VehicleSearchResult[];
  }
}

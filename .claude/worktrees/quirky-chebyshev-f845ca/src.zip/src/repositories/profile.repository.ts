import { supabase } from '@/integrations/supabase/client';

export interface ProfileRow {
  user_id: string;
  full_name: string | null;
}

export interface EnsureProfileRpcResult {
  success?: boolean;
  action?: string;
  full_name?: string;
}

export class ProfileRepository {
  async findByUserId(userId: string): Promise<ProfileRow | null> {
    const { data, error } = await supabase
      .from('profils')
      .select('full_name')
      .eq('user_id', userId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null;
      console.error('Error fetching profile:', error);
      throw new Error(error.message);
    }
    return data ? { user_id: userId, full_name: (data as { full_name: string | null }).full_name } : null;
  }

  async ensureProfileRpc(): Promise<EnsureProfileRpcResult | null> {
    const { data, error } = await supabase.rpc('assurer_profil_utilisateur');
    if (error) {
      console.error('Error ensuring profile:', error);
      throw new Error(error.message);
    }
    return data as EnsureProfileRpcResult | null;
  }
}
